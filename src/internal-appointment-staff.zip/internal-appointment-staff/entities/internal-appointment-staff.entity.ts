export class InternalAppointmentStaff {
    id:number;
}
